package view;

import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import model.Usuario;
import util.SessaoUsuario;

public class FrmPrincipal
        extends javax.swing.JFrame {

    public FrmPrincipal() {

        initComponents();

        setLocationRelativeTo(null);

        setExtendedState(
                javax.swing.JFrame.MAXIMIZED_BOTH
        );

        carregarUsuario();

        aplicarPermissoes();
    }

    private void carregarUsuario() {

        Usuario usuario =
                SessaoUsuario.getUsuarioLogado();

        if (usuario != null) {

            lblUsuario.setText(
                    "Usuário: " + usuario.getNome()
            );

            lblNivel.setText(
                    "Nível: " + usuario.getNivel()
            );

        } else {

            lblUsuario.setText(
                    "Usuário: não identificado"
            );

            lblNivel.setText(
                    "Nível: não identificado"
            );
        }
    }

    private void aplicarPermissoes() {

        if (SessaoUsuario.isMaster()) {

            mnuUsuarios.setEnabled(true);

            mnuContasPagar.setEnabled(true);

        } else {

            mnuUsuarios.setEnabled(false);

            mnuContasPagar.setEnabled(false);
        }
    }

    private void abrirTela(JInternalFrame tela) {

        for (JInternalFrame frame :
                jDesktopPane1.getAllFrames()) {

            if (frame.getClass().equals(tela.getClass())) {

                try {

                    if (frame.isIcon()) {
                        frame.setIcon(false);
                    }

                    frame.setSelected(true);
                    frame.toFront();

                } catch (Exception erro) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Não foi possível selecionar a tela.",
                            "Erro",
                            JOptionPane.ERROR_MESSAGE
                    );
                }

                return;
            }
        }

        jDesktopPane1.add(tela);

        tela.setVisible(true);

        centralizarInternalFrame(tela);
    }

    private void centralizarInternalFrame(
            JInternalFrame tela
    ) {

        int x =
                (jDesktopPane1.getWidth()
                - tela.getWidth()) / 2;

        int y =
                (jDesktopPane1.getHeight()
                - tela.getHeight()) / 2;

        if (x < 0) {
            x = 0;
        }

        if (y < 0) {

            y = 0;
        }

        tela.setLocation(x, y);
    
}


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        lblUsuario = new javax.swing.JLabel();
        lblNivel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mnuSair = new javax.swing.JMenuItem();
        mnuLogout = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        mnuClientes = new javax.swing.JMenuItem();
        mnuFornecedores = new javax.swing.JMenuItem();
        mnuProdutos = new javax.swing.JMenuItem();
        mnuUsuarios = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        mnuCompras = new javax.swing.JMenuItem();
        mnuVendas = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        mnuContasPagar = new javax.swing.JMenuItem();
        mnuComprasReceber = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        mnuSobre = new javax.swing.JMenuItem();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 226, Short.MAX_VALUE)
        );

        lblUsuario.setText("Usuário:  ");

        lblNivel.setText("Nível: ");

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MENU PRINCIPAL");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jMenu1.setText("Sistema");

        mnuSair.setText("Sair");
        mnuSair.addActionListener(this::mnuSairActionPerformed);
        jMenu1.add(mnuSair);

        mnuLogout.setText("Logout");
        mnuLogout.addActionListener(this::mnuLogoutActionPerformed);
        jMenu1.add(mnuLogout);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Cadastros");

        mnuClientes.setText("Clientes");
        mnuClientes.addActionListener(this::mnuClientesActionPerformed);
        jMenu2.add(mnuClientes);

        mnuFornecedores.setText("Fornecedores");
        mnuFornecedores.addActionListener(this::mnuFornecedoresActionPerformed);
        jMenu2.add(mnuFornecedores);

        mnuProdutos.setText("Produtos");
        mnuProdutos.addActionListener(this::mnuProdutosActionPerformed);
        jMenu2.add(mnuProdutos);

        mnuUsuarios.setText("Usuarios");
        mnuUsuarios.addActionListener(this::mnuUsuariosActionPerformed);
        jMenu2.add(mnuUsuarios);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Movimentos");

        mnuCompras.setText("Compras");
        mnuCompras.addActionListener(this::mnuComprasActionPerformed);
        jMenu3.add(mnuCompras);

        mnuVendas.setText("Vendas");
        mnuVendas.addActionListener(this::mnuVendasActionPerformed);
        jMenu3.add(mnuVendas);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Financeiro");

        mnuContasPagar.setText("Contas a Pagar");
        mnuContasPagar.addActionListener(this::mnuContasPagarActionPerformed);
        jMenu4.add(mnuContasPagar);

        mnuComprasReceber.setText("Contas a Receber");
        mnuComprasReceber.addActionListener(this::mnuComprasReceberActionPerformed);
        jMenu4.add(mnuComprasReceber);

        jMenuBar1.add(jMenu4);

        jMenu5.setText("Ajuda");

        mnuSobre.setText("Sobre");
        mnuSobre.addActionListener(this::mnuSobreActionPerformed);
        jMenu5.add(mnuSobre);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(lblUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 226, Short.MAX_VALUE)
                .addComponent(lblNivel)
                .addGap(51, 51, 51))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUsuario)
                    .addComponent(lblNivel))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSairActionPerformed
        int resposta =
                JOptionPane.showConfirmDialog(
                        this,
                        "Deseja realmente encerrar o FerragemGK?",
                        "Sair",
                        JOptionPane.YES_NO_OPTION
                );

        if (resposta == JOptionPane.YES_OPTION) {

            System.exit(0);
        }

    }//GEN-LAST:event_mnuSairActionPerformed

    private void mnuProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuProdutosActionPerformed
        abrirTela(new FrmProduto());
    }//GEN-LAST:event_mnuProdutosActionPerformed

    private void mnuClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuClientesActionPerformed
        abrirTela(new FrmCliente());
    }//GEN-LAST:event_mnuClientesActionPerformed

    private void mnuFornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuFornecedoresActionPerformed
        abrirTela(new FrmFornecedor());
    }//GEN-LAST:event_mnuFornecedoresActionPerformed

    private void mnuUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuUsuariosActionPerformed
    if (!SessaoUsuario.isMaster()) {

        JOptionPane.showMessageDialog(
                this,
                "Acesso permitido somente para usuário MASTER."
        );

        return;
    }

    abrirTela(new FrmUsuario());
    }//GEN-LAST:event_mnuUsuariosActionPerformed

    private void mnuComprasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuComprasActionPerformed
abrirTela(new FrmCompra());
    }//GEN-LAST:event_mnuComprasActionPerformed

    private void mnuVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuVendasActionPerformed
abrirTela(new FrmVenda());
    }//GEN-LAST:event_mnuVendasActionPerformed

    private void mnuContasPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuContasPagarActionPerformed
if (!SessaoUsuario.isMaster()) {

        JOptionPane.showMessageDialog(
                this,
                "Acesso permitido somente para usuário MASTER."
        );

        return;
    }

    abrirTela(new FrmContasPagar());
    }//GEN-LAST:event_mnuContasPagarActionPerformed

    private void mnuComprasReceberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuComprasReceberActionPerformed
abrirTela(new FrmContasReceber());
    }//GEN-LAST:event_mnuComprasReceberActionPerformed

    private void mnuSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSobreActionPerformed
    JOptionPane.showMessageDialog(
            this,
            "FerragemGK\n"
            + "Sistema desenvolvido em Java Swing\n"
            + "Banco de dados PostgreSQL"
    );
    }//GEN-LAST:event_mnuSobreActionPerformed

    private void mnuLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuLogoutActionPerformed
    int resposta =
            JOptionPane.showConfirmDialog(
                    this,
                    "Deseja encerrar a sessão atual?",
                    "Logout",
                    JOptionPane.YES_NO_OPTION
            );

    if (
            resposta
            == JOptionPane.YES_OPTION
    ) {

        SessaoUsuario.encerrar();

        FrmLogin login =
                new FrmLogin();

        login.setVisible(true);

        dispose();
    }//GEN-LAST:event_mnuLogoutActionPerformed

}
   
    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(() -> new FrmPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JLabel lblNivel;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JMenuItem mnuClientes;
    private javax.swing.JMenuItem mnuCompras;
    private javax.swing.JMenuItem mnuComprasReceber;
    private javax.swing.JMenuItem mnuContasPagar;
    private javax.swing.JMenuItem mnuFornecedores;
    private javax.swing.JMenuItem mnuLogout;
    private javax.swing.JMenuItem mnuProdutos;
    private javax.swing.JMenuItem mnuSair;
    private javax.swing.JMenuItem mnuSobre;
    private javax.swing.JMenuItem mnuUsuarios;
    private javax.swing.JMenuItem mnuVendas;
    // End of variables declaration//GEN-END:variables
}
