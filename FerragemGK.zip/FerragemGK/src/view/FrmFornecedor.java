
package view;

import dao.FornecedorDAO;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Fornecedor;
import util.SessaoUsuario;


public class FrmFornecedor extends javax.swing.JInternalFrame {


   public FrmFornecedor() {

    initComponents();

    configurarTela();

    listarFornecedores();

    limparCampos();
}
   
private final FornecedorDAO fornecedorDAO = new FornecedorDAO();

private long idFornecedorSelecionado = 0;

private void configurarTela() {

    txtCodigo.setEditable(false);

    btnExcluir.setEnabled(
            SessaoUsuario.isMaster()
    );

    tblFornecedores.setSelectionMode(
            javax.swing.ListSelectionModel
                    .SINGLE_SELECTION
    );

    tblFornecedores.setAutoCreateRowSorter(
            true
    );

    tblFornecedores.setModel(
            criarModeloTabela()
    );
}
private DefaultTableModel criarModeloTabela() {

    return new DefaultTableModel(
            new Object[]{
                "Código",
                "Razão Social",
                "Nome Fantasia",
                "CNPJ",
                "Telefone",
                "Email",
                "Cidade",
                "UF",
                "Ativo"
            },
            0
    ) {

        @Override
        public boolean isCellEditable(
                int row,
                int column
        ) {

            return false;
        }
    };
}
private void preencherTabela(
        List<Fornecedor> fornecedores
) {

    DefaultTableModel modelo =
            (DefaultTableModel)
            tblFornecedores.getModel();

    modelo.setRowCount(0);

    for (
            Fornecedor fornecedor :
            fornecedores
    ) {

        modelo.addRow(
                new Object[]{
                    fornecedor.getIdFornecedor(),
                    fornecedor.getRazaoSocial(),
                    fornecedor.getNomeFantasia(),
                    fornecedor.getCnpj(),
                    fornecedor.getTelefone(),
                    fornecedor.getEmail(),
                    fornecedor.getCidade(),
                    fornecedor.getUf(),
                    fornecedor.isAtivo()
                            ? "Sim"
                            : "Não"
                }
        );
    }
}
private void listarFornecedores() {

    try {

        preencherTabela(
                fornecedorDAO.listarTodos()
        );

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar fornecedores."
                + erro.getMessage()
        );
    }
}
private void limparCampos() {

    idFornecedorSelecionado = 0;

    txtCodigo.setText("");
    txtRazaoSocial.setText("");
    txtNomeFantasia.setText("");
    txtCnpj.setText("");
    txtTelefone.setText("");
    txtEmail.setText("");
    txtEndereco.setText("");
    txtNumero.setText("");
    txtComplemento.setText("");
    txtBairro.setText("");
    txtCidade.setText("");
    txtCep.setText("");

    cmbUf.setSelectedIndex(0);

    chkAtivo.setSelected(true);

    txtRazaoSocial.requestFocus();
}
private boolean validarCampos() {

    if (
            txtRazaoSocial
            .getText()
            .trim()
            .isEmpty()
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Informe a razão social."
        );

        txtRazaoSocial.requestFocus();

        return false;
    }

    if (
            txtCnpj
            .getText()
            .trim()
            .isEmpty()
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Informe o CNPJ."
        );

        txtCnpj.requestFocus();

        return false;
    }

    if (
            cmbUf.getSelectedIndex() == 0
            && !txtCidade
                    .getText()
                    .trim()
                    .isEmpty()
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Selecione a UF."
        );

        cmbUf.requestFocus();

        return false;
    }

    return true;
}
private Fornecedor criarFornecedorComCampos() {

    Fornecedor fornecedor =
            new Fornecedor();

    fornecedor.setIdFornecedor(
            idFornecedorSelecionado
    );

    fornecedor.setRazaoSocial(
            txtRazaoSocial.getText().trim()
    );

    fornecedor.setNomeFantasia(
            txtNomeFantasia.getText().trim()
    );

    fornecedor.setCnpj(
            txtCnpj.getText().trim()
    );

    fornecedor.setTelefone(
            txtTelefone.getText().trim()
    );

    fornecedor.setEmail(
            txtEmail.getText().trim()
    );

    fornecedor.setEndereco(
            txtEndereco.getText().trim()
    );

    fornecedor.setNumero(
            txtNumero.getText().trim()
    );

    fornecedor.setComplemento(
            txtComplemento.getText().trim()
    );

    fornecedor.setBairro(
            txtBairro.getText().trim()
    );

    fornecedor.setCidade(
            txtCidade.getText().trim()
    );

    if (
            cmbUf.getSelectedIndex() > 0
    ) {

        fornecedor.setUf(
                cmbUf
                .getSelectedItem()
                .toString()
        );

    } else {

        fornecedor.setUf("");
    }

    fornecedor.setCep(
            txtCep.getText().trim()
    );

    fornecedor.setAtivo(
            chkAtivo.isSelected()
    );

    return fornecedor;
}
private void carregarFornecedorSelecionado() {

    int linha =
            tblFornecedores
            .getSelectedRow();

    if (linha == -1) {

        JOptionPane.showMessageDialog(
                this,
                "Selecione um fornecedor na tabela."
        );

        return;
    }

    int linhaModelo =
            tblFornecedores
            .convertRowIndexToModel(
                    linha
            );

    long idFornecedor =
            Long.parseLong(
                    tblFornecedores
                    .getModel()
                    .getValueAt(
                            linhaModelo,
                            0
                    )
                    .toString()
            );

    try {

        Fornecedor fornecedor =
                fornecedorDAO.buscarPorId(
                        idFornecedor
                );

        if (
                fornecedor == null
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Fornecedor não encontrado."
            );

            return;
        }

        preencherCampos(
                fornecedor
        );

        tabFornecedor.setSelectedIndex(
                0
        );

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar fornecedor."
                + erro.getMessage()
        );
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabFornecedor = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        txtEndereco = new javax.swing.JTextField();
        btnCancelar = new javax.swing.JButton();
        txtNumero = new javax.swing.JTextField();
        chkAtivo = new javax.swing.JCheckBox();
        txtComplemento = new javax.swing.JTextField();
        txtBairro = new javax.swing.JTextField();
        txtCidade = new javax.swing.JTextField();
        cmbUf = new javax.swing.JComboBox<>();
        txtCodigo = new javax.swing.JTextField();
        btnNovo = new javax.swing.JButton();
        txtCnpj = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        txtTelefone = new javax.swing.JTextField();
        btnAlterar = new javax.swing.JButton();
        txtEmail = new javax.swing.JTextField();
        txtCep = new javax.swing.JTextField();
        btnExcluir = new javax.swing.JButton();
        txtNomeFantasia = new javax.swing.JTextField();
        txtRazaoSocial = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFornecedores = new javax.swing.JTable();
        cmbFiltro = new javax.swing.JComboBox<>();
        txtPesquisa = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnListarTodos = new javax.swing.JButton();
        btnCarregar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastro de Fornecedores");

        txtEndereco.setBorder(javax.swing.BorderFactory.createTitledBorder("Endereço"));

        btnCancelar.setBackground(new java.awt.Color(204, 153, 0));
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(this::btnCancelarActionPerformed);

        txtNumero.setBorder(javax.swing.BorderFactory.createTitledBorder("Número"));

        chkAtivo.setText("Ativo");
        chkAtivo.addActionListener(this::chkAtivoActionPerformed);

        txtComplemento.setBorder(javax.swing.BorderFactory.createTitledBorder("Complemento"));

        txtBairro.setBorder(javax.swing.BorderFactory.createTitledBorder("Bairro"));

        txtCidade.setBorder(javax.swing.BorderFactory.createTitledBorder("Cidade"));

        cmbUf.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));
        cmbUf.setBorder(javax.swing.BorderFactory.createTitledBorder("UF"));
        cmbUf.addActionListener(this::cmbUfActionPerformed);

        txtCodigo.setBorder(javax.swing.BorderFactory.createTitledBorder("Código"));
        txtCodigo.addActionListener(this::txtCodigoActionPerformed);

        btnNovo.setBackground(new java.awt.Color(153, 153, 255));
        btnNovo.setText("Novo");
        btnNovo.addActionListener(this::btnNovoActionPerformed);

        txtCnpj.setBorder(javax.swing.BorderFactory.createTitledBorder("CNPJ"));

        btnSalvar.setBackground(new java.awt.Color(51, 255, 51));
        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(this::btnSalvarActionPerformed);

        txtTelefone.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefone"));

        btnAlterar.setBackground(new java.awt.Color(255, 255, 102));
        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);

        txtEmail.setBorder(javax.swing.BorderFactory.createTitledBorder("E-mail"));

        txtCep.setBorder(javax.swing.BorderFactory.createTitledBorder("CEP"));

        btnExcluir.setBackground(new java.awt.Color(255, 51, 51));
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        txtNomeFantasia.setBorder(javax.swing.BorderFactory.createTitledBorder("Nome Fantasia"));

        txtRazaoSocial.setBorder(javax.swing.BorderFactory.createTitledBorder("Razao Social"));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(txtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtCep, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtComplemento))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtRazaoSocial, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtNomeFantasia, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(txtCnpj, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addGap(0, 39, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(chkAtivo, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(btnNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(12, 12, 12)
                                    .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(cmbUf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtRazaoSocial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNomeFantasia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbUf, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chkAtivo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNovo)
                    .addComponent(btnAlterar)
                    .addComponent(btnExcluir)
                    .addComponent(btnCancelar)
                    .addComponent(btnSalvar))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        tabFornecedor.addTab("Cadastro", jPanel1);

        tblFornecedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblFornecedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblFornecedoresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblFornecedores);

        cmbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Filtros", "RAZAO SOCIAL", "NOME FANTASIA", "ID", "CNPJ", "EMAIL" }));
        cmbFiltro.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar por:"));
        cmbFiltro.addActionListener(this::cmbFiltroActionPerformed);

        txtPesquisa.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisa"));

        btnLocalizar.setBackground(new java.awt.Color(153, 255, 153));
        btnLocalizar.setForeground(new java.awt.Color(255, 255, 255));
        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(this::btnLocalizarActionPerformed);

        btnListarTodos.setText("Listar Todos");
        btnListarTodos.addActionListener(this::btnListarTodosActionPerformed);

        btnCarregar.setText("Carregar");
        btnCarregar.addActionListener(this::btnCarregarActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnListarTodos)
                    .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(txtPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnCarregar, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(38, 38, 38)
                .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(144, 144, 144))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLocalizar, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnListarTodos, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCarregar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        tabFornecedor.addTab("Consulta", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(tabFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 661, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabFornecedor)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void chkAtivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkAtivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkAtivoActionPerformed

    private void cmbUfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbUfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbUfActionPerformed

    private void txtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        limparCampos();
        tabFornecedor.setSelectedIndex(0);
    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
if (
            idFornecedorSelecionado != 0
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Existe um fornecedor carregado para edição."
                + "Utilize Alterar ou clique em Novo."
        );

        return;
    }

    if (!validarCampos()) {

        return;
    }

    try {

        Fornecedor fornecedor =
                criarFornecedorComCampos();

        long codigo =
                fornecedorDAO.cadastrar(
                        fornecedor
                );

        JOptionPane.showMessageDialog(
                this,
                "Fornecedor cadastrado com sucesso."
                + "Código: "
                + codigo
        );

        limparCampos();

        listarFornecedores();

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Não foi possível cadastrar o fornecedor."
                + erro.getMessage()
        );
    }

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed

        if (
            idFornecedorSelecionado == 0
        ) {

            JOptionPane.showMessageDialog(
                this,
                "Localize e carregue um Fornecedor antes de alterar."
            );

            return;
        }

        if (!validarCampos()) {

            return;
        }

        int resposta =
        JOptionPane.showConfirmDialog(
            this,
            "Deseja salvar as alterações deste Fornecedor?",
            "Alterar Fornecedor",
            JOptionPane.YES_NO_OPTION
        );

        if (
            resposta
            != JOptionPane.YES_OPTION
        ) {

            return;
        }

        try {

            Fornecedor fornecedor =
            criarFornecedorComCampos();

            boolean alterado =
            fornecedorDAO.alterar(
                fornecedor
            );

            if (alterado) {

                JOptionPane.showMessageDialog(
                    this,
                    "Fornecedor alterado com sucesso."
                );

                limparCampos();

                listarFornecedores();

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Nenhum registro foi alterado."
                );
            }

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(
                this,
                "Não foi possível alterar o Fornecedor.\n"
                + erro.getMessage()
            );
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (
            !SessaoUsuario.isMaster()
        ) {

            JOptionPane.showMessageDialog(
                this,
                "Você não possui permissão para excluir Fornecedores."
            );

            return;
        }

        if (
            idFornecedorSelecionado == 0
        ) {

            JOptionPane.showMessageDialog(
                this,
                "Localize e carregue um Fornecedor antes de excluir."
            );

            return;
        }

        int resposta =
        JOptionPane.showConfirmDialog(
            this,
            "Deseja realmente excluir este Fornecedor?",
            "Excluir Fornecedor",
            JOptionPane.YES_NO_OPTION
        );

        if (
            resposta
            != JOptionPane.YES_OPTION
        ) {

            return;
        }

        try {

            boolean excluido =
            fornecedorDAO.excluir(
                idFornecedorSelecionado
            );

            if (excluido) {

                JOptionPane.showMessageDialog(
                    this,
                    "Fornecedor excluído com sucesso."
                );

                limparCampos();

                listarFornecedores();

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Fornecedor não encontrado."
                );
            }

        } catch (Exception erro) {

            JOptionPane.showMessageDialog(
                this,
                "Não foi possível excluir o Fornecedor.\n"
                + "O Fornecedor pode possuir registros vinculados.\n"
                + erro.getMessage()
            );
        }
        btnExcluir.setEnabled(SessaoUsuario.isMaster());
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void tblFornecedoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblFornecedoresMouseClicked
        if (
            evt.getClickCount() == 2
        ) {

            carregarFornecedorSelecionado();
        }
    }//GEN-LAST:event_tblFornecedoresMouseClicked

    private void cmbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFiltroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFiltroActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
    String pesquisa =
            txtPesquisa
            .getText()
            .trim();

    String filtro =
            cmbFiltro
            .getSelectedItem()
            .toString();

    if (pesquisa.isEmpty()) {

        listarFornecedores();

        return;
    }

    if (
            filtro.equals("ID")
    ) {

        try {

            Long.parseLong(
                    pesquisa
            );

        } catch (
                NumberFormatException erro
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Para pesquisar por ID informe apenas números."
            );

            txtPesquisa.requestFocus();

            return;
        }
    }

    try {

        List<Fornecedor> fornecedores =
                fornecedorDAO.pesquisar(
                        filtro,
                        pesquisa
                );

        preencherTabela(
                fornecedores
        );

        if (
                fornecedores.isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Nenhum fornecedor encontrado."
            );
        }

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Erro na pesquisa."
                + erro.getMessage()
        );
    }

    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnListarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarTodosActionPerformed
        txtPesquisa.setText("");
        listarFornecedores();
    }//GEN-LAST:event_btnListarTodosActionPerformed

    private void btnCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregarActionPerformed
        carregarFornecedorSelecionado();
    }//GEN-LAST:event_btnCarregarActionPerformed
private String valorTexto(
        String valor
) {

    if (valor == null) {

        return "";
    }

    return valor;
}
private void preencherCampos(
        Fornecedor fornecedor
) {

    idFornecedorSelecionado =
            fornecedor.getIdFornecedor();

    txtCodigo.setText(
            String.valueOf(
                    fornecedor.getIdFornecedor()
            )
    );

    txtRazaoSocial.setText(
            valorTexto(
                    fornecedor.getRazaoSocial()
            )
    );

    txtNomeFantasia.setText(
            valorTexto(
                    fornecedor.getNomeFantasia()
            )
    );

    txtCnpj.setText(
            valorTexto(
                    fornecedor.getCnpj()
            )
    );

    txtTelefone.setText(
            valorTexto(
                    fornecedor.getTelefone()
            )
    );

    txtEmail.setText(
            valorTexto(
                    fornecedor.getEmail()
            )
    );

    txtEndereco.setText(
            valorTexto(
                    fornecedor.getEndereco()
            )
    );

    txtNumero.setText(
            valorTexto(
                    fornecedor.getNumero()
            )
    );

    txtComplemento.setText(
            valorTexto(
                    fornecedor.getComplemento()
            )
    );

    txtBairro.setText(
            valorTexto(
                    fornecedor.getBairro()
            )
    );

    txtCidade.setText(
            valorTexto(
                    fornecedor.getCidade()
            )
    );

    txtCep.setText(
            valorTexto(
                    fornecedor.getCep()
            )
    );

    if (
            fornecedor.getUf() != null
            && !fornecedor
                    .getUf()
                    .isBlank()
    ) {

        cmbUf.setSelectedItem(
                fornecedor.getUf()
        );

    } else {

        cmbUf.setSelectedIndex(
                0
        );
    }

    chkAtivo.setSelected(
            fornecedor.isAtivo()
    );
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnCarregar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnListarTodos;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JComboBox<String> cmbFiltro;
    private javax.swing.JComboBox<String> cmbUf;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane tabFornecedor;
    private javax.swing.JTable tblFornecedores;
    private javax.swing.JTextField txtBairro;
    private javax.swing.JTextField txtCep;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtCnpj;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtComplemento;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNomeFantasia;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtRazaoSocial;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
